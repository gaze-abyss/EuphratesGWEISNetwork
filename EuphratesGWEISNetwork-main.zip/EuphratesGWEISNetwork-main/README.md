# EuphratesGWEISNetwork
Modeling Genome-wide by Environment Interactions through Omnigenic Interactome Networks
